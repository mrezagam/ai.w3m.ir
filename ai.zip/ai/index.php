<?php require "core/load.php";

/* ------------------------------------------------------
    $programmer['name']       = "Reza";
    $programmer['Telegram']   = "mrezagam";
    $programmer['mobile']     = "+989213161317";
   ---------------------------------------------------- */
// print_r($config); EXIT;

?><!DOCTYPE html>
<html lang="<?php echo $config['HTML']['meTa']['lang']; ?>" dir="<?php echo $config['HTML']['meTa']['dir']; ?>">
<head>

    <meta charset="<?php echo $config['HTML']['meTa']['charset']; ?>">
    <meta name="viewport" content="<?php echo $config['HTML']['meTa']['viewport']; ?>">
    <title>ربات هوشمند <?php echo ($config['HTML']['TiTTle']); ?></title>

    <meta name="description" content="<?php echo ($config['HTML']['meTa']['descripTion']); ?>">
    <meta property="og:title" content="<?php echo ($config['HTML']['meTa']['og']['TiTTle']); ?>">
    <meta property="og:description" content="<?php echo ($config['HTML']['meTa']['og']['descripTion']); ?>">
    <meta property="og:image" content="<?php echo ($config['HTML']['meTa']['og']['image']); ?>">
    <meta property="og:url" content="<?php echo ($config['HTML']['meTa']['og']['url']); ?>">
    <meta property="og:type" content="<?php echo ($config['HTML']['meTa']['og']['type']); ?>">

<?php if ($config['HTML']['fonT'] === "iranYekan") { ?>
    <link rel="stylesheet" href="./fonT/iranYekan/load.css?v=<?php echo ($config['verson']); ?>">
<?php } else { ?>
    <link rel="stylesheet" href="./fonT/BeiruTi/load.css?v=<?php echo ($config['verson']); ?>">
<?php } ?>

    <link rel="stylesheet" href="./css/base.css?v=<?php echo ($config['verson']); ?>">
    <link rel="stylesheet" href="./css/responsive.css?v=<?php echo ($config['verson']); ?>">
    <link rel="stylesheet" href="./css/login.css?v=<?php echo ($config['verson']); ?>">

    <link rel="icon" href="<?php echo ($config['HTML']['meTa']['og']['image']); ?>" type="image/png">
    <link rel="apple-touch-icon" href="<?php echo ($config['HTML']['meTa']['og']['image']); ?>">
    <link rel="icon" href="<?php echo ($config['HTML']['meTa']['og']['image']); ?>" sizes="64x64">
    
    <script>
        
        var GPT    = <?php echo json_encode($config['GPT']); ?>;
        var user   = <?php echo json_encode($config['user']); ?>;
        var PrompT = '<?php if (isset($_GET['p'])) {echo $_GET['p'];}?>';

    </script>
    <style>
        #Thread .res::before 
        {background-image: url('<?php echo ($config['HTML']['meTa']['og']['image']); ?>');}
    </style>

</head>
<body class="<?php echo $Theme = (isset($_COOKIE['Theme']) && $_COOKIE['Theme'] === 'dark') ? 'dark' : 'lighT'; ?>">

    <div id="loader">
        <div class="loader-wrapper">
            <div class="spinner"></div>
            <img src="<?php echo htmlspecialchars($config['HTML']['meTa']['og']['image']); ?>" alt="Logo" class="loader-logo">
        </div>
    </div>

    <main>
        <div id="Thread">
            <div id="header">
                <span id="menuTogglebTn" class="menuTogglebTn" onclick="menuToggle()">
                    <img src="./media/icon/menuTogglebTn.png" alt="MENO">
                </span>
                <a id="newThreadbTn" class="newThreadbTn" href="?ConversaTion=1">
                    <img src="./media/icon/newThreadbTn.png" alt="NEW">
                </a>
                
                <span id="LoginbTn">
                    <?php if($user['id'] == 0) { ?>
                    
                    <?php } else {  ?>
                        حساب کاربری 
                    <?php } ?>
                </span>
                
                <div id="popboxmask"></div>

                <div id="userpopbox">

                    <div class="popboxConTenT login">

                    <?php if($user['id'] == 0) { ?>

                        <span class="closebTn" onclick="closeUserPopbox()">
                            <img src="./media/icon/close.png" alt="بستن">
                        </span>


                        <div id="loginBox">

                            <form id="loginFormA" method="post" onsubmit="return login('a')">

                                <h1>ورود به حساب کاربری</h1>

                                <fieldset class="mb-3">
                                    <label> با شماره مبایل</label>
                                    <div id="mobile">
                                        <span>+98</span><input type="number" name="mobile" placeholder="Ex: 9120000000">
                                    </div>
                                    <button type="submit">دریافت کد ورود</button>
                                </fieldset>
                                <div class="msg"></div>
                            </form>

                            <form id="loginFormB" class="d-none" action="login.php" method="post" onsubmit="return login('b')">
                                <h1>تایید کد ورود</h1>
                                <h3>
                                    کد تایید به 
                                    <span class="fw-bold"></span>
                                    ارسال شد
                                    <div onclick="goTo_loginFormA()">
                                        ویرایش شماره موبایل
                                        <div id="Timer"></div>
                                    </div>
                                </h3>
                                <fieldset>
                                    <div class="d-none" id="fullname">
                                        <span>نام و نام‌خانوادگی</span>
                                        <input type="text" name="fullname" placeholder="">
                                    </div>

                                    <div id="code">
                                        <span>کد تایید</span>
                                        <input type="number" name="code" placeholder="Ex: 1234">
                                    </div>
                                    <button type="submit">تایید و ورود</button>
                                </fieldset>

                                <div class="msg"></div>

                            </form>

                        </div>
                        
                        <?php if($config['Telegram']['id'] != "") { ?>
                        <div class="ya">یا </div></p>
                        <a href="https://t.me/<?php echo $config['Telegram']['id']; if($ThreadId != ""){echo "?start=login_" . $ThreadId;} ?>" target="_blank" id="TelegramLoginBTn">
                            <img src="./media/icon/Telegram.png" alt="Telegram">
                            ورود خودکار از طریق تلگرام
                        </a>
                        <div><small> با <strong class="red"> فیلترشکن روشن </strong> روی دکمه بزنید </small></div>
                        <?php } ?>

                        <?php } else {  ?>
                            

                        <?php } ?>

                    </div>
                </div>
                <div class="d-none-im" id="ThemeToggle">
                    <img id="ThemeIcon" src="./media/icon/<?php echo $Theme; ?>.png" alt="<?php echo htmlspecialchars($config['domain']); ?>">
                </div>
            </div>

            <div id="Threadbox">
                <div id="infoBox">
                    <div id="logo">
                    <img src="<?php echo htmlspecialchars($config['HTML']['meTa']['og']['image']); ?>" alt="fav icon">
                    </div>
                    <h1><?php echo ($config['HTML']['h1']); ?></h1>
                    <h2><?php echo ($config['HTML']['h2']); ?></h2>
                </div>
            </div>

            <div class="loader"></div>

            <button id="helpbTn" onclick="help()">?</button>
            <div id="alarm"><?php echo htmlspecialchars($config['HTML']['ChaTbox']['alarm']); ?></div>
        </div>

        <form id="in">
            <textarea name="PrompT" id="PrompT" placeholder="بنویسید ..." oninput="PrompTResize()" require><?php echo $PrompT; ?></textarea>
            <button id="sub">
                <img src="./media/icon/sub.png" alt="SEND">
            </button>
        </form>
    </main>

    <div id="side">
        <div>
            <span class="menuTogglebTn" onclick="menuToggle()">
                <img src="./media/icon/menuTogglebTn.png" alt="MENU">
            </span>
            <a class="newThreadbTn" href="?ConversaTion=1">
                <img src="./media/icon/newThreadbTn.png" alt="NEW">
            </a>
        </div>

        <?php
            echo '<ul>';
                echo '<a href="?ConversaTion=1"><li>گفتگوی تازه</li></a>';
                if($config['Telegram']['id'] != "")
                {
                    echo '<a href="https://t.me/' . $config['Telegram']['id']; if($ThreadId != ""){echo "?start=login_" . $ThreadId;} echo '" target="_blank"><li>ربات تلگرام</li></a>';
                }
                echo '<div id="ConversaTion"></div>';
            echo '</ul>';
        ?>

        <footer>
            <a href="<?php echo $config['HTML']['hub']['href'] ?>"><?php echo $config['HTML']['hub']['TexT'] ?></a>
            <small>Version <?php echo $config['verson'] ?></small>
        </footer>

    </div>
    <div id="SideMask" onclick="menuToggle()"></div>

    <script src="./lib/jquery.js?v=<?php echo ($config['verson']); ?>"></script>
    <script src="./js/base.js?v=<?php echo ($config['verson']); ?>"></script>
    <script src="./js/login.js?v=<?php echo ($config['verson']); ?>"></script>
    
</body>
</html>