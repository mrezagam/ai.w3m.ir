$(document).ready(function()
{
    $('#loginBox input').on('input', function()
    {
        $('#loginBox .res').html('');
    });

    $('#loginBox input').on('focus', function()
    {
        $(this).css('border', 'none');
        
    }).on('blur', function() {
        $(this).css('border', '');
    });
    
    SeTuserInfo();

});

function login(sTep) {
    if (sTep == "a") {
        $('#loginFormA button[type=submit]').prop('disabled', true);
        $('#loginFormA button[type=submit]').html('<span class="spinner" style="right: calc(50% - 16px);width: 23px;height: 24px;left: unset;top: 10px;"></span>');

        var mobile = $("#mobile input").val();

        $.ajax({
            url: api + "user/login.php",
            method: "POST",
            data: { sTep: sTep, mobile: mobile },
            xhrFields: { withCredentials: true },
            crossDomain: true,
            success: function(res) {
                if (res.was == "bad") {
                    $('#loginFormA .msg').html(res.msg);
                } else if (res.was == "god") {
                    if (res.userId == 0) {
                        $('#fullname').show();
                    } else {
                        $('#fullname').hide();
                    }

                    $('#loginFormA').fadeOut(300, function() {
                        $('#loginFormB').fadeIn(300);
                        $('#loginFormB h3 span').html(res.mobile);
                    });

                    loginTimer(120, document.querySelector('#Timer'));
                }

                $('#loginFormA button[type=submit]').prop('disabled', false);
                $('#loginFormA button[type=submit]').html('دریافت کد ورود');
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#loginFormA .msg').html("خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.");
                $('#loginFormA button[type=submit]').prop('disabled', false);
                $('#loginFormA button[type=submit]').html('دریافت کد ورود');
                console.error("Request failed: " + textStatus + ", " + errorThrown);
            }
        });

    } else if (sTep == "b") {
        $('#loginFormB button[type=submit]').prop('disabled', true);
        $('#loginFormB button[type=submit]').html('<span class="spinner" style="right: calc(50% - 16px);width: 23px;height: 24px;left: unset;top: 10px;"></span>');

        var mobile = $("#mobile input").val();
        var fullname = $("#fullname input").val();
        var code = $("#code input").val();

        $.ajax({
            url: api + "user/login.php",
            method: "POST",
            data: { sTep: sTep, mobile: mobile, fullname: fullname, code: code },
            xhrFields: { withCredentials: true },
            crossDomain: true,
            success: function(res) {
                if (res.was == "bad") {
                    $('#loginFormB .msg').html(res.msg);
                    $('#loginFormB button[type=submit]').html('تایید و ورود');
                    $('#loginFormB button[type=submit]').prop('disabled', false);
                } else if (res.was == "god") {
                    $('#loginFormB .msg').html("تایید شد لطفا صبر کنید");
                    SeTuserInfo();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#loginFormB .msg').html("خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.");
                $('#loginFormB button[type=submit]').html('تایید و ورود');
                $('#loginFormB button[type=submit]').prop('disabled', false);
                console.error("Request failed: " + textStatus + ", " + errorThrown);
            }
        });
    }

    return false;
}


function goTo_loginFormA()
{
    $('#loginFormB').fadeOut(300, function()
    {
        $('#loginFormA').fadeIn(300);
    });   
}

let loginTimerInTerval;
function loginTimer(Time, elem) {
    elem.textContent = "";
    if (loginTimerInTerval) {
        clearInterval(loginTimerInTerval);
    }
    let timer = Time, minutes, seconds;
    loginTimerInTerval = setInterval(function () {
        minutes = Math.floor(timer / 60);
        seconds = timer % 60;

        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;

        elem.textContent = minutes + ":" + seconds;

        if (--timer < 0) {
            clearInterval(loginTimerInTerval);
            goTo_loginFormA();
        }
    }, 1000);
}






function SeTuserInfo()
{
    $.ajax({
        url: api + 'user/id.php',
        method: 'POST',
        data: {id:GPT.id},
        xhrFields: { withCredentials: true },
        crossDomain: true,
        success: function(res) {
            if(res.was == "god") {
                if(res.user != false) {
                    $('#LoginbTn').html('حساب');

                    let conTenT = `
                        <span class="closebTn" onclick="closeUserPopbox()">
                            <img src="./media/icon/close.png" alt="بستن">
                        </span>

                        <div style="margin: 0 0 32px 0;">
                            <h2>اطلاعات حساب</h2>
                            <small style="color: red;cursor: pointer; margin: 0 0 32px 0;display: block;" onclick="logou()">خروج از حساب</small>
                            <p>نام: ${res.user.name}</p>
                            <p>موبایل: ${res.user.whaTsapp}</p>
                        </div>
                        <div style="color: dark;cursor: pointer;" onclick="closeUserPopbox();subPrompT();">ادامه گفتگو</div>
                    `;

                    $('#userpopbox .popboxConTenT').html(conTenT);

                    // جایگزینی فهرست گفتگوها
                    const $convList = $('#ConversaTion');
                    $convList.empty();

                    if (res.ConversaTions && Object.keys(res.ConversaTions).length > 0) {
                        $convList.append('<div class="TiTr">تاریخچه گفتگوها</div>');

                        Object.values(res.ConversaTions).forEach(Thread => {
                            if (Thread.TiTel) {
                                const $a = $('<a></a>').attr('href', `?ConversaTion=${encodeURIComponent(Thread.TiTel)}`);
                                const $li = $('<li></li>').text(Thread.TiTel);
                                $a.append($li);
                                $convList.append($a);
                            }
                        });
                    }

                    user = res.user;
                } else {
                    $('#LoginbTn').html('ورود');
                    user.id = 0;
                }
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("Request failed: " + textStatus + ", " + errorThrown);
        }
    });
}



function logou() {
    if(confirm("آیا مطمئن هستید که می‌خواهید خارج شوید؟")) {
        $.ajax({
            url: api + "user/logou.php",
            method: "POST",
            success: function(res) {
                alert("خروج با موفقیت انجام شد.");
                location.reload();
            },
            error: function() {
                alert("خطا در خروج، دوباره تلاش کنید.");
            }
        });
    }
}