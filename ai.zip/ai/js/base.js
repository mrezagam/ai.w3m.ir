var api = "https://ai.w3m.ir/api/v1/";

if (!user) 
{
  user = {};
  user.id = 0;
}

$('#PrompT').on('input keypress', function(event)
{

  if (event.which === 13 && !event.shiftKey)
  { subPrompT(); }

  if ($(this).val().trim() !== "")
  {
    $('#sub').css('background', '#000');
    $('#sub img').css('filter', 'invert(1)');
  }
  else
  {
    $('#sub').css('background', '#FFF');
    $('#sub img').css('filter', 'invert(0)');
  }

});

$('#sub').on('click', function(event) { event.preventDefault(); subPrompT(); });

function subPrompT() 
{


  if(GPT.login == "yes")
  {
    if(user.id == 0)
    {
      if($('#Thread #Threadbox').find('.res').length > 1)
      {
        Threadin("برای دسترسی به ادامه‌ی گفتگو، نیاز است وارد حساب کاربری شوید.", "TexT", "res");
        setTimeout(() => {
          openuserpopbox(GPT.ConversaTion, false);
        }, 3000);
        return;
      }
    }
  }

  const PrompT = $('#PrompT').val();
  if(PrompT == ""){return;}


  $('#PrompT').prop('disabled', true);
  $('#PrompT').val("");
  
  PrompTResize();
  
  Threadin(PrompT, "TexT", "PrompT",0);

  $('#Thread').scrollTop($('#Thread')[0].scrollHeight + 100);
  
  async function STream() {


      function geTRandomMessage() {
        const randomIndex = Math.floor(Math.random() * loadingMessages.length);
        return loadingMessages[randomIndex];
      }

        

      // $('#Thread .loader').show("");

      var newmsg = $('<div class="res"></div>');
      $('#Thread #Threadbox').append(newmsg);
      
      var mainres = $('<div class="mainres">در حال ارسال درخواست</div>');

      newmsg.append(mainres);

      $('#Thread').scrollTop($('#Thread')[0].scrollHeight);


      const response = await fetch(
          api + 'chaT/web.php?GPTid=' + GPT.id +
          '&PrompT=' + encodeURIComponent(PrompT) +
          '&ConversaTion=' + GPT.ConversaTion,
          {
            method: 'GET',
            credentials: 'include'
          }
      );

      const reader = response.body.getReader();
      const decoder = new TextDecoder();


      var flag = true;
      
      let done = false;
      while (!done) {
          const { value, done: readerDone } = await reader.read();
          done = readerDone;

          if (value) 
          {

            const chunk = decoder.decode(value, { stream: true });

            console.log(chunk);

            try {

                const jsonParTs = exTracTJSON(chunk);
                jsonParTs.forEach(sTr => {

                    let json;
                    try { json = JSON.parse(sTr);  }
                    catch {return; }
                    if (json.was == "load")
                    {
                      mainres.html('<div id="TypeLoader"><span>در حال جستجوی اینترنت…</span><span>در حال بررسی اطلاعات و منابع…</span><span>در حال تحلیل داده‌ها…</span><span>در حال آماده‌سازی پاسخ…</span></div>');
                      $('#Thread').scrollTop($('#Thread')[0].scrollHeight);
                    }

                    if (json.was == "delTa")
                    {
                        if(flag)
                        {
                          mainres.html("");
                          flag = false;
                        }
                        mainres.append(json.delTa);
                    }

                    if (json.was == "done")
                    {

                      newmsg.remove();
                      Threadin(json.res, "TexT", "res",0);

                      $('#Thread').scrollTop($('#Thread')[0].scrollHeight);

                      GPT.ConversaTion = json.ConversaTion;
                      SeT_Cookie("ConversaTion",GPT.ConversaTion,256,PrompT);

                    }

                });

            } catch (e) 
            { console.warn("WE " + chunk); }

          }
      }

      $('#PrompT').prop('disabled', false);

      $('#PrompT').focus();

  }
  
  STream();


  function exTracTJSON(text) {
      let result = [];
      let depth = 0;
      let start = -1;

      for (let i = 0; i < text.length; i++) {

          if (text[i] === '{') {
              if (depth === 0) start = i;
              depth++;
          }
          else if (text[i] === '}') {
              depth--;
              if (depth === 0 && start !== -1) {
                  result.push(text.substring(start, i + 1));
                  start = -1;
              }
          }
      }

      return result.length ? result : [];
  }


  /*
    
  $.ajax({
    url: api + 'chaT/web.php',
    method: 'POST',
    data: { 
        GPTid:        GPT.id,
        PrompT:       PrompT,
        ConversaTion: GPT.ConversaTion,
    },
    success: function(response)
    {

      if (response.was == "god") 
      {

        Threadin(response.res, response.formaT, "res");
        GPT.ConversaTion = response.ConversaTion;
        SeT_Cookie("w3m_ai_ConversaTion",GPT.ConversaTion,256,PrompT)

      } 
      else if (response.was == "bad")
      {
      }

      $('#PrompT').prop('disabled', false);
      $('#Thread .loader').hide("");
      $('#in #PrompT').focus();

    },
    error: function(error)
    {
      Threadin("لطفا اتصال اینترنت خود را برسی کنید", "TexT", "res");
      $('#PrompT').prop('disabled', false);
      $('#Thread .loader').hide("");
    }
    
  });

  */


}

$('.code per').click(function() {
  alert(1);
  var text = $(this).text();
  navigator.clipboard.writeText(text).then(function() {
      alert('محتوا کپی شد!');
  });
});


var svgcopy = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-sm"><path fill-rule="evenodd" clip-rule="evenodd" d="M7 5C7 3.34315 8.34315 2 10 2H19C20.6569 2 22 3.34315 22 5V14C22 15.6569 20.6569 17 19 17H17V19C17 20.6569 15.6569 22 14 22H5C3.34315 22 2 20.6569 2 19V10C2 8.34315 3.34315 7 5 7H7V5ZM9 7H14C15.6569 7 17 8.34315 17 10V15H19C19.5523 15 20 14.5523 20 14V5C20 4.44772 19.5523 4 19 4H10C9.44772 4 9 4.44772 9 5V7ZM5 9C4.44772 9 4 9.44772 4 10V19C4 19.5523 4.44772 20 5 20H14C14.5523 20 15 19.5523 15 19V10C15 9.44772 14.5523 9 14 9H5Z" fill="currentColor"></path></svg>`;

var sTarT = 'no';

function Threadin(message, formaT, dclass, speed = 1) 
{

  if (formaT === "TexT") {
    if (sTarT == 'no') {
      sTarT = 'yes';
      $('#infoBox').hide();
      $('main #in').css('bottom', '2rem');
    }

    message = message.replace(/ã€\d+:\d+â€ sourceã€‘/g, '');
    message = message.replace(/【\d+:\d+†source】/g, '');
    message = message.replace(/\*\*(.*?)\*\*/g, '<span class="bold">$1</span>');
    message = message.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a class="LinkbTn" href="$2" target="_blank">$1</a>');

    var newmsg = $('<div class="' + dclass + '"></div>');
    $('#Thread #Threadbox').append(newmsg);

    if (isSafari()) {

      var mainres = $('<div class="mainres"></div>');
      newmsg.append(mainres);
      mainres.append(message);
      return;

    }
    
    function TNC() {
      var mainres = $('<div class="mainres"></div>');
      newmsg.append(mainres);

      var brCount = 0;

      var chunks = [];
      var regex = /<a [^>]+>[^<]+<\/a>|<span class="bold">[^<]+<\/span>/g;
      var lastIndex = 0;
      var match;

      while ((match = regex.exec(message)) !== null) {
        if (match.index > lastIndex) {
          chunks.push({ text: message.slice(lastIndex, match.index), html: false });
        }
        chunks.push({ text: match[0], html: true });
        lastIndex = regex.lastIndex;
      }

      if (lastIndex < message.length) {
        chunks.push({ text: message.slice(lastIndex), html: false });
      }

      var chunkIndex = 0;
      var charIndex = 0;

      function processChar() {
        if (chunkIndex >= chunks.length) {
          return;
        }

        var chunk = chunks[chunkIndex];

        if (chunk.html) {
          mainres.append(chunk.text);
          chunkIndex++;
          charIndex = 0;
          setTimeout(processChar, speed);
        } else {
          if (charIndex >= chunk.text.length) {
            chunkIndex++;
            charIndex = 0;
            processChar();
            return;
          }

          var char = chunk.text.charAt(charIndex);

          if (chunk.text.slice(charIndex, charIndex + 3) === "```") {
            const randomId = 'CodeBlock_' + Math.random().toString(36).substr(2, 9);

            var codeBlock = '<div class="code">' +
              '<button class="copy" onclick="copyToClipboardFromId(\'' + randomId + '\', this)">' +
              svgcopy + 'copy code' + '</button>';

            charIndex += 3;

            const languages = ["ash", "sql", "php", "css", "html", "java", "c", "cpp", "py", "js", "ts", "go", "rb", "swift", "r", "lua", "perl", "rust", "kotlin", "dart", "scala"];

            for (let lang of languages) {
              if (chunk.text.slice(charIndex, charIndex + lang.length) === lang) {
                codeBlock += '<span class="lang">' + lang + '</span>';
                charIndex += lang.length;
                break;
              }
            }

            charIndex++;
            codeBlock += '</div>';
            mainres.append(codeBlock);

            var lasTCodeBlock = mainres.find('.code').last();
            var maincode = $('<div class="maincode" id="' + randomId + '"><div>');
            lasTCodeBlock.append(maincode);

            while (charIndex < chunk.text.length && chunk.text.slice(charIndex, charIndex + 3) !== "```") {
              var c = chunk.text.charAt(charIndex);
              maincode.append(c);
              charIndex++;
            }

            charIndex += 3;
          } else if (char === "\n") {
            if (brCount === 0) {
              mainres.append('<br>');
            }
            brCount++;
            charIndex++;
          } else {
            mainres.append(char);
            charIndex++;
            brCount = 0;
          }

          if (speed == 0) {
            processChar();
          } else {
            setTimeout(processChar, speed);
          }
        }
      }

      processChar();
    }

    TNC();
    $('#Thread').scrollTop($('#Thread')[0].scrollHeight);

  }

}

function isSafari() 
{
  const ua = navigator.userAgent;
  return /Safari/i.test(ua) && !/Chrome|CriOS|FxiOS|EdgiOS/i.test(ua);
}

function copyToClipboardFromId(id, bTn)
{

  TexT = document.getElementById(id).innerText.replace(/&nbsp;/g, ' ');
  copyToClipboard(TexT);

  /*
  bTn.innerText = 'copied!'; 
  setTimeout(() => {
    bTn.innerText = svgcopy + 'copy code'; 
  }, 3000);
  */

}

function copyToClipboard(TexT) 
{
  TexT = TexT.replace(/\&nbsp;/g, ' ');
  
  const textarea = document.createElement('textarea');
  textarea.value = TexT;
  
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  
  document.body.removeChild(textarea);
}


function PrompTResize() {
  var prompt = $('#PrompT');
  var text = prompt.val();
  var lineBreaks = (text.match(/\n/g) || []).length;

  prompt.css('height', 'auto');

  if (lineBreaks > 0) {
    var sh = prompt[0].scrollHeight;
    prompt[0].style.height = Math.min(Math.max(sh, 32), 200) + 'px';
  } else {
    prompt[0].style.height = '32px';
  }
}


function menuToggle() 
{
  var sideMenu = $("#side");
  var mainContent = $("main");
  var windowWidth = $(window).width();

  if (sideMenu.css("right") === "0px") {

    sideMenu.animate({ right: "-260px" }, 100);
    
    if (windowWidth >= 1124) {
      mainContent.animate({ width: "100%", marginRight: "0" }, 156);
    }
    else
    {
      $('#SideMask').fadeOut(366);
    }

    $('#menuTogglebTn,#newThreadbTn').show(156);

  } else {

    sideMenu.animate({ right: "0px" }, 300);
    
    if (windowWidth >= 1124) {
      mainContent.animate({
        width: windowWidth - 260 + "px",
        marginRight: "260px"
      }, 156);
    }
    else
    {
      mainContent.animate({ width: "100%", marginRight: "0" }, 156);
      $('#SideMask').fadeIn(366);
    }

    $('#menuTogglebTn,#newThreadbTn').hide(156);

  }
}

function help()
{
  var q = 'خودتو معرفی کن و توضیح بده در چه زمینه‌هایی می‌تونی کمک کنی و چه کارهایی انجام بدی.';
  $('#PrompT').val(q);
  subPrompT();
}


let cl = null;
$('#LoginbTn').click(function () { openuserpopbox(GPT.ConversaTion,false); });


function openuserpopbox(ConversaTion = "",Hide=true) 
{
  $('#popboxmask').fadeIn(200);
  $('#userpopbox').css('display', 'flex').hide().fadeIn(300);
}

function closeUserPopbox() {
  $('#userpopbox').fadeOut(200);
  $('#popboxmask').fadeOut(300);

  if (cl !== null) {
    clearInterval(cl);
    cl = null;
  }
}

$('#popboxmask,.closebTn').click(function () {
closeUserPopbox();
});


function checkSubscripTionSTaTus(T) {
  const TimesTTamp = parseInt(T, 10);
  if (isNaN(TimesTTamp)) {
    return `<p class="message">تاریخ اشتراک نامعتبر است.</p>`;
  }
  const expDate = new Date(TimesTTamp * 1000); // به میلی‌ثانیه
  const now = new Date();
  const diffTime = expDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays > 0) {
    return `<p class="god">اشتراک شما فعال است.</p><p class="msg"> ${diffDays} روز دیگر باقی مانده است.</p>`;
  } else {
    return `
      <p class="bad">اشتراک شما به پایان رسیده است.</p>
      <a class="SubBTn" href="${sPayUrl}">تمدید اشتراک</a>
    `;
  }
}

async function SeT_Cookie(name, value, days, PrompT = "")
{
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }

    const cookieValue = typeof value === "string" ? value : JSON.stringify(value);
    document.cookie = `${name}=${encodeURIComponent(cookieValue)}${expires}; path=/`;

    if (name !== "ConversaTion") return;

    // خواندن کوکی قبلی
    let arr = [];
    const existing = document.cookie
        .split('; ')
        .find(row => row.startsWith('ConversaTion='));

    if (existing) {
        try {
            arr = JSON.parse(decodeURIComponent(existing.split('=')[1]));
            if (!Array.isArray(arr)) arr = [];
        } catch {
            arr = [];
        }
    }

    // جلوگیری از تکرار
    if (arr.some(item => item.id === value)) return;

    // ساخت عنوان از ۳ کلمه اول پرامپت
    let TiTle = "";
    if (PrompT) {
        TiTle = PrompT
            .trim()
            .split(/\s+/)
            .slice(0, 3)
            .join(" ");
    }

    const newItem = {
        id: value,
        TiTle: TiTle || "گفتگوی جدید",
        date: new Date().toISOString()
    };

    arr.unshift(newItem);
    if (arr.length > 10) arr.length = 10;

    document.cookie = `ConversaTion=${encodeURIComponent(JSON.stringify(arr))}${expires}; path=/`;
}


function ConversaTionTiTle(PrompT) {
    return $.ajax({
        url: api + "/ConversaTionTiTTle.php",
        method: "POST",
        data: { PrompT: PrompT },
        dataType: "json"
    })
    .then(function(response) {
        if (response && response.res && response.res.choices && response.res.choices[0]) {
            return response.res.choices[0].message.content;
        }
        return response.TexT || null;
    })
    .catch(function(err) {
        console.error("خطا در دریافت داده:", err);
        return null;
    });
}

function GeT_Cookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(nameEQ) === 0) {
            try {
                return JSON.parse(decodeURIComponent(c.substring(nameEQ.length)));
            } catch (e) {
                return decodeURIComponent(c.substring(nameEQ.length));
            }
        }
    }
    return null;
}

function del_Cookie(name) {
    document.cookie = name + "=; Max-Age=0; path=/;";
}


function logouT()
{
  del_Cookie("w3m_ai_user");
  del_Cookie("ThreadId");
  location.reload();
}


$('#ThemeToggle').click(function () 
{
    if ($('body').hasClass('lighT')) {
        $('body').removeClass('lighT').addClass('dark');
        $('#ThemeIcon').attr('src','./media/icon/dark.png');
        SeT_Cookie("Theme", "dark", 256);
    } else {
        $('body').removeClass('dark').addClass('lighT');
        $('#ThemeIcon').attr('src', './media/icon/lighT.png');
        SeT_Cookie("Theme", "lighT", 256);
    }
});

function GeTThread(GPTId,ThreadId,PrompT='',load="yes")
{
  $.ajax({
      url: 'https://ai.w3m.ir/api/GeTThread.php',
      method: 'POST',
      data: {
        GPTId: GPTId,
        ThreadId: ThreadId,
        limiT: "user"
      },
      success: function (response) 
      {

        if (response.was === "god") 
        {
          if(response.res)
          {
            ThreadId = response.res.id;
            SeT_Cookie("ConversaTion",response.res.id,256,PrompT);
          }
        }

        if (response.Thread && Array.isArray(response.Thread)) 
        {
          if(load == "yes")
          {
            
            response.Thread.forEach(function (item) {
              if (item.role === "user") 
              {
                Threadin(item.content[0].text.value, "TexT", "PrompT", 0);
              } else if (item.role === "GPT") {
                Threadin(item.content[0].text.value, "TexT", "res", 0);
              }
            });

          }
        }

        if(PrompT != "")
        {subPrompT();}
        
      },
      error: function (xhr, status, error) {
        console.error("AJAX Error:", error);
      }
  });
}

if(GPT.ConversaTion == "new")
{
  var sload = "yes";

}
else
{
  var sload = "no";
}

// GeTThread(GPT.id,ThreadId,PrompT,sload);

if(PrompT != "")
{
  $('#PrompT').val(PrompT);
  subPrompT();
}


$(window).on('load', function () {
  $('#loader').fadeOut(500, function () {$(this).remove();});
});


function modelbTn() {$('#modelbTn ul').toggle(256);}


function ToolbTn()
{ $('#ToolsBox').toggle(256); }

$(document).on('click', function (e)
{
  if (!$(e.target).closest('#modelbTn').length) {
    $('#modelbTn ul').hide();
  }
});



