<?php

$config = 
[
    'domain'  => preg_replace('/:\d+$/', '', preg_replace('/[^a-z0-9\.\-]/i', '', $_SERVER['HTTP_HOST'])),
    'PaTh'   => rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'),

    'kilid'  => "1024",
    'verson' => '0.9.1',

    'GPT' => [
        'id' => 1,
        'name' => preg_replace('/:\d+$/', '', preg_replace('/[^a-z0-9\.\-]/i', '', $_SERVER['HTTP_HOST'])),
        'ConversaTion' => 'new',
        'PrompT' => isset($_GET['PrompT']) ? $_GET['PrompT'] : "",
        'login' => "yes",
    ],

    'Telegram' => 
    [
        'Token'         => "",
        'username'      => "",
    ],

    'whaTsapp' => 
    [
        'mobile'        => "",
    ],

    'user' =>  
    [
        'id' => 0,
    ],

    'HTML' => [

        'h1' => 'من ربات هوشمند' . preg_replace('/:\d+$/', '', preg_replace('/[^a-z0-9\.\-]/i', '', $_SERVER['HTTP_HOST'])) . ' هستم',
        'h2'   => 'چطور میتونم به شما کمک کنم ؟',
        'TiTTle' => 'پشتیبان هوشمند',
        'fonT'   => 'iranYekan',
        'meTa' => [
            'lang'         => 'fa',
            'dir'          => 'rtl',
            'charset'      => 'UTF-8',
            'viewport'     => 'width=device-width, initial-scale=1.0',
            'descripTion'  => 'پاسخ‌گویی سریع، دقیق و کاملاً هوشمند',
            'og' => 
            [
                'TiTTle'      => 'پشتیبان هوشمند',
                'descripTion' => 'پاسخ‌گویی سریع، دقیق و کاملاً هوشمند',
                'image'       => 'https://ai.w3m.ir/load/media/logo/64.png',
                'url'         => 'ai',
                'type'        => 'website',
            ],
        ],
        'ChaTbox' => [
            'alarm'         => 'هسته‌ی قدرتمند OpenAI با توسعه‌ی w3m',
        ],
        'hub' =>  
        [
            'href' => 'https://ai.w3m.ir/',
            'TexT' => 'w3mAI',
        ],
    ],
];

?>